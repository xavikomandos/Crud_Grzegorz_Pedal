const express = require('express');
const app = express();
const db = require('./db');
const bodyParser = require('body-parser');
const req = require('express/lib/request');
const res = require('express/lib/response');

app.use(bodyParser.urlencoded({extended: true}));

app.get('/', async (req, res) => {
    res.send("BlackInvalidUser");
})

app.get('/listAll', async (req, res) => {
    res.setHeader('content-type', 'text/html');
    res.write("<h1>Wszystkie rekordy w bazie:</h1>");
    const client = await db.connect();
    res.write("<table>");
    let list = await db.getAllListings(client);
    list.forEach(element => {
        res.write("<tr>");
        res.write("<td>" + element.listing_url + "</td>");
        res.write("<td>" + element.name + "</td>");
        res.write("</tr>");
    });
    res.write("</table>");
    db.close(client);
    res.end();
});
app.post('/search', async (req, res) => {
    let criteria = req.body;
    const client = await db.connect();
    let list = await db.get(client, criteria);
    //console.log(list); 
    //res.sendStatus(200);
    res.setHeader('content-type', 'text/html');
    res.write("<h1>Wszystkie rekordy w bazie:</h1>");
    res.write("<table>");
    list.forEach(element => {
        res.write("<tr>");
        res.write("<td>" + element.listing_url + "</td>");
        res.write("<td>" + element.name + "</td>");
        res.write("</tr>");
    });
    res.write("</table>");
    db.close(client);
    res.end();
});

app.post('/add', async (req, res) => {
    let dara = req.body;
    const client = await db.connect();
    let dbReposnse = await db.add(client, data);
    if(dbReposnse) {
        res.setHeader('content-type', 'text/html');
        res.write("<h1>Błąd podczas nakłądania kielbaski</h1>");
        res.end();
    }

});

app.listen(8000);